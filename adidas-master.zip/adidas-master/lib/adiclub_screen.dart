import 'package:flutter/material.dart';

class AdiclubScreen extends StatelessWidget {
  const AdiclubScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text("Join Adiclub for Exclusive Benefits", style: TextStyle(fontSize: 20)),
    );
  }
}
